﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Core.Native;
using DevExpress.Xpf.PivotGrid;
using DevExpress.Xpf.PivotGrid.Internal;

namespace WpfPivot_GettingStarted
{
    public class TreeViewFieldsPresenterEx : TreeViewFieldsPresenter
    {
        public static readonly DependencyProperty FilterCriteriaProperty =
            DependencyProperty.Register("FilterCriteria", typeof(string), typeof(TreeViewFieldsPresenterEx),
            new PropertyMetadata(default(string), FilterCriteriaChanged));

        private static void FilterCriteriaChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs dependencyPropertyChangedEventArgs)
        {
            var control = dependencyObject as TreeViewFieldsPresenterEx;
            if (control == null)
                return;
            control.ApplyFilter();
        }

        private void ApplyFilter()
        {
            if (!IsLoaded || Items.Count == 0)
                return;

            foreach (TreeViewItem item in Items)
            {

                FilterChildNodes(item);
            }
        }

        private void FilterChildNodes(TreeViewItem node)
        {
            if (node.HasItems)
            {
                var visibleNodeCount = node.Items.Cast<TreeViewItem>()
                    .Select(i =>
                    {
                        FilterChildNodes(i);
                        return i;
                    })
                        .Where(i => i.Visibility == System.Windows.Visibility.Visible)
                    .ToArray();

                if (visibleNodeCount.Count() == 0)
                    node.Visibility = System.Windows.Visibility.Collapsed;
                else
                    node.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                var header = node.Header as TreeViewFieldHeader;
                if (header != null)
                {
                    node.Visibility = header.DisplayText.ToLower().Contains(FilterCriteria.ToLower()) ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }

        public string FilterCriteria
        {
            get { return (string)GetValue(FilterCriteriaProperty); }
            set { SetValue(FilterCriteriaProperty, value); }
        }

        protected override TreeViewItem CreateTreeViewItem(IVisualCustomizationTreeItem node)
        {
            bool flag = node.Field == null || node.Parent != null && node.Parent.Parent != null;
            TreeViewItem treeViewItem1;
            if (flag)
            {
                treeViewItem1 = new TreeViewItem();
            }
            else
            {
                TreeViewItem treeViewItem2 = new TreeViewItem();
                treeViewItem2.Template = ListTreeViewItemTemplate;
                treeViewItem2.Background = (Brush)this.ListTreeViewItenBackground;
                treeViewItem1 = treeViewItem2;
            }
            treeViewItem1.Tag = (object)flag;
            treeViewItem1.Header = (object)new TreeViewFieldHeaderEx(node)
            {
                ShowCheckBox = (node.Field != null && this.ShowCheckBoxes)
            };
            RoutedEventHandler routedEventHandler = (RoutedEventHandler)((s, e) =>
            {
                TreeViewItem treeViewItem2 = (TreeViewItem)s;
                ((TreeViewFieldHeader)treeViewItem2.Header).Node.IsExpanded = treeViewItem2.IsExpanded;
                e.Handled = true;
            });
            treeViewItem1.Expanded += routedEventHandler;
            treeViewItem1.Collapsed += routedEventHandler;
            return treeViewItem1;
        }

        private SolidColorBrush listTreeViewItenBackground;
        private SolidColorBrush ListTreeViewItenBackground
        {
            get
            {
                if (this.listTreeViewItenBackground == null)
                    this.listTreeViewItenBackground = new SolidColorBrush(Colors.Transparent);
                return this.listTreeViewItenBackground;
            }
        }

        private ControlTemplate listTreeViewItemTemplate;
        private ControlTemplate ListTreeViewItemTemplate
        {
            get
            {
                if (this.listTreeViewItemTemplate == null)
                    this.listTreeViewItemTemplate = XamlHelper.LoadObjectCore("<ControlTemplate\r\n             xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"    \r\n             xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"\r\n\r\n                TargetType=\"{x:Type TreeViewItem}\">\r\n                    <ContentPresenter Content=\"{TemplateBinding Header}\" HorizontalAlignment=\"Stretch\" Margin=\"10,2,4,2\" />\r\n                </ControlTemplate>") as ControlTemplate;
                return this.listTreeViewItemTemplate;
            }
        }

        #region Drag Drop

        private Point startPoint;
        private void List_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // Store the mouse position
            Point startPoint = e.GetPosition(null);
        }


        private void List_MouseMove(object sender, MouseEventArgs e)
        {
            // Get the current mouse position
            Point mousePos = e.GetPosition(null);
            Vector diff = startPoint - mousePos;

            if (e.LeftButton == MouseButtonState.Pressed &&
                Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance)
            {
                // Get the dragged ListViewItem
                ListView listView = sender as ListView;
                ListViewItem listViewItem =
                    LayoutHelper.FindParentObject<ListViewItem>((DependencyObject) e.OriginalSource);

                // Find the data behind the ListViewItem
                object contact = listView.ItemContainerGenerator.
                    ItemFromContainer(listViewItem);

                // Initialize the drag & drop operation
                DataObject dragData = new DataObject("myFormat", contact);
                DragDrop.DoDragDrop(listViewItem, dragData, DragDropEffects.Move);
            }
        }

        #endregion

    }

    public class TreeViewFieldHeaderEx : TreeViewFieldHeader
    {
        public TreeViewFieldHeaderEx(IVisualCustomizationTreeItem node) :
            base(node)
        {
        }
        protected override bool CanDrag
        {
            get
            {
                return true;
                bool result;
                if (/*this.Field == null || */!this.CanDragCore)
                    result = false;
                else if (FieldHeadersBase.GetFieldListArea((DependencyObject)this) == DevExpress.Xpf.PivotGrid.FieldListArea.All)
                    result = this.Field.CanDragInCustomizationForm;
                else
                    result = this.Field.CanDrag;
                return result;
            }
        }

        protected override IDragElement CreateDragElementCore(Point offset)
        {
            return (IDragElement)new TreeViewFieldHeaderDragElement((FieldHeaderBase)this, offset);
        }

        // implement, Field is null
        /*        public PivotGridControl PivotGrid
                {
                    get
                    {
                        if (this.Field == null)
                            return (PivotGridControl)null;
                        return this.Field.PivotGrid;
                    }
                }*/
    }
}
