﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows;
using System.Windows.Controls.Primitives;
using DevExpress.Xpf.Core.Native;
using DevExpress.Xpf.PivotGrid;
using DevExpress.Xpf.PivotGrid.Internal;

namespace WpfPivot_GettingStarted {
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window {
        public MainWindow() {
            InitializeComponent();
        }

        private void PivotGridControl1_OnFieldSizeChanged(object sender, PivotFieldEventArgs e)
        {
            Debug.WriteLine("\t OnFieldSizeChanged");
        }

        private void PivotGridControl1_OnFieldAreaChanging(object sender, PivotFieldAreaChangingEventArgs e)
        {
            Debug.WriteLine($"\t OnFieldAreaChanging: {e.Field.FieldName}, area {e.NewArea}");
        }

        private void PivotGridControl1_OnFieldAreaChanged(object sender, PivotFieldEventArgs e)
        {
            Debug.WriteLine($"\t OnFieldAreaChanged: '{e.Field.Name}' '{e.Field.FieldName}', area {e.Field.Area} {e.Field.AreaIndex}");
        }

        private void PivotGridControl1_OnFieldVisibleChanging(object sender, PivotFieldVisibleChangingEventArgs e)
        {
            Debug.WriteLine($"\t OnFieldVisibleChanging: '{e.Field.Name}' '{e.Field.FieldName}', visible {e.Field.Visible}");
        }

        private void PivotGridControl1_OnFieldVisibleChanged(object sender, PivotFieldEventArgs e)
        {
            Debug.WriteLine($"\t OnFieldVisibleChanged: '{e.Field.Name}' '{e.Field.FieldName}', visible {e.Field.Visible}, area {e.Field.Area}");
        }

        private void OnDeferredUpdateClick(object sender, RoutedEventArgs e)
        {
            pivotGridControl1.DeferredUpdates = (bool)DeferredUpdatesButton.IsChecked;
        }

        private void GetVisibleFields2_Click(object sender, RoutedEventArgs e)
        {
            FieldListLayoutSelector layoutSelector = (FieldListLayoutSelector)LayoutHelper.FindElementByName(pivotExcelFieldList, "LayoutSelector");
            PivotFieldListControl dataAreaContent = (PivotFieldListControl) layoutSelector.DataAreaContent;
            InnerFieldListControl innerFieldList = LayoutHelper.FindElementByType<InnerFieldListControl>(dataAreaContent);
            InnerFieldListControl innerFieldList2 = (InnerFieldListControl) LayoutHelper.FindElementByName(dataAreaContent, "FieldListHeaders");
            var equal = innerFieldList == innerFieldList2;

            var items = innerFieldList.ItemsSource;
        }

        private void GetVisibleFieldsClick(object sender, RoutedEventArgs e)
        {
            var visibleFields = pivotGridControl1.Fields.Where(x => x.Visible).ToList();

            dynamic pivotGridControlDynamic = new PrivateMembersInvoker(pivotGridControl1);
            PivotGridWpfData pivotGridWpfData = (PivotGridWpfData)pivotGridControlDynamic.Data;
            var fieldListFields = pivotGridWpfData.FieldListFields;
            // if (fieldListFields.DeferUpdates)
            fieldListFields.SetFieldsToData();


            visibleFields = pivotGridControl1.Fields.Where(x => x.Visible).ToList();

            Debug.WriteLine("");
            TraceAreaFields(FieldArea.FilterArea, visibleFields);
            TraceAreaFields(FieldArea.ColumnArea, visibleFields);
            TraceAreaFields(FieldArea.RowArea, visibleFields);
            TraceAreaFields(FieldArea.DataArea, visibleFields);
            Debug.WriteLine("");
        }

        private static void TraceAreaFields(FieldArea area, List<PivotGridField> allFields)
        {
            var areaFields = allFields
                .Where(x => x.Area == area)
                .OrderBy(x => x.AreaIndex).ToList();

            Debug.WriteLine($"\t {area} ({areaFields.Count}):");
            foreach (var field in areaFields)
                Debug.WriteLine($"\t     '{field.Name}' '{field.FieldName}");
        }
    }
}
