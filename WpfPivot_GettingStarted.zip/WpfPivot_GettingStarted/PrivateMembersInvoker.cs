﻿using System;
using System.Diagnostics;
using System.Dynamic;
using System.Globalization;
using System.Reflection;

namespace WpfPivot_GettingStarted
{
    public class PrivateMembersInvoker : DynamicObject
    {
        static BindingFlags _bindingFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        private readonly object _obj;
        private readonly Type _type;
        public PrivateMembersInvoker(object obj)
        {
            _obj = obj;
            _type = obj.GetType();
        }

        public object UnderlyingObject => _obj;

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            var propInfo = _type.GetProperty(binder.Name, _bindingFlags);
            if (propInfo != null)
            {
                var value = propInfo.GetValue(_obj);

                Debug.WriteLine($"{nameof(PrivateMembersInvoker)}::TryGetMember: value {value.GetType().Name}");

                result = new PrivateMembersInvoker(value);
                return true;
            }

            return base.TryGetMember(binder, out result);
        }

        public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
        {
            MethodInfo methodInfo = _type.GetMethod(binder.Name, _bindingFlags);
            if (methodInfo != null)
            {
                var value = methodInfo.Invoke(_obj, _bindingFlags, null, args, CultureInfo.CurrentCulture);

                Debug.WriteLine($"{nameof(PrivateMembersInvoker)}::TryInvokeMember: value {value.GetType().Name}");

                result = new PrivateMembersInvoker(value);
                return true;
            }

            return base.TryInvokeMember(binder, args, out result);
        }

        public override bool TryConvert(ConvertBinder binder, out object result)
        {
            if (binder.ReturnType.IsInstanceOfType(UnderlyingObject))
            {
                result = UnderlyingObject;
                return true;
            }

            return base.TryConvert(binder, out result);
        }

        public override bool TryInvoke(InvokeBinder binder, object[] args, out object result)
        {
            return base.TryInvoke(binder, args, out result);
        }
    }
}