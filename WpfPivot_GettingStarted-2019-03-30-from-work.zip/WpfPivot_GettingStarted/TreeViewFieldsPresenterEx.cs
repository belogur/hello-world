﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Core.Internal;
using DevExpress.Xpf.Core.Native;
using DevExpress.Xpf.PivotGrid;
using DevExpress.Xpf.PivotGrid.Internal;
using DevExpress.XtraPivotGrid.Customization;
using ImageHelper = DevExpress.Xpf.Core.Native.ImageHelper;

namespace WpfPivot_GettingStarted
{
    public class TreeViewFieldsPresenterEx : TreeViewFieldsPresenter
    {
        public static readonly DependencyProperty CanDragDropFolderProperty =
            DependencyProperty.RegisterAttached("CanDragDropFolder", typeof(bool), typeof(TreeViewFieldHeaderEx), new PropertyMetadata(false));

        public static bool GetCanDragDropFolder(DependencyObject obj)
        {
            return (bool)obj.GetValue(CanDragDropFolderProperty);
        }

        public static void SetCanDragDropFolder(DependencyObject obj, bool value)
        {
            obj.SetValue(CanDragDropFolderProperty, value);
        }


        public static readonly DependencyProperty FilterCriteriaProperty =
            DependencyProperty.Register("FilterCriteria", typeof(string), typeof(TreeViewFieldsPresenterEx),
            new PropertyMetadata(default(string), FilterCriteriaChanged));

        private static void FilterCriteriaChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs dependencyPropertyChangedEventArgs)
        {
            var control = dependencyObject as TreeViewFieldsPresenterEx;
            if (control == null)
                return;
            control.ApplyFilter();
        }

        private void ApplyFilter()
        {
            if (!IsLoaded || Items.Count == 0)
                return;

            foreach (TreeViewItem item in Items)
            {

                FilterChildNodes(item);
            }
        }

        private void FilterChildNodes(TreeViewItem node)
        {
            if (node.HasItems)
            {
                var visibleNodeCount = node.Items.Cast<TreeViewItem>()
                    .Select(i =>
                    {
                        FilterChildNodes(i);
                        return i;
                    })
                        .Where(i => i.Visibility == System.Windows.Visibility.Visible)
                    .ToArray();

                if (visibleNodeCount.Count() == 0)
                    node.Visibility = System.Windows.Visibility.Collapsed;
                else
                    node.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                var header = node.Header as TreeViewFieldHeader;
                if (header != null)
                {
                    node.Visibility = header.DisplayText.ToLower().Contains(FilterCriteria.ToLower()) ? Visibility.Visible : Visibility.Collapsed;
                }
            }
        }

        public string FilterCriteria
        {
            get { return (string)GetValue(FilterCriteriaProperty); }
            set { SetValue(FilterCriteriaProperty, value); }
        }

        protected override TreeViewItem CreateTreeViewItem(IVisualCustomizationTreeItem node)
        {
            bool flag = node.Field == null
                || node.Parent != null && node.Parent.Parent != null  // at first or second level children
                ;

            var folder = node as PivotCustomizationTreeNodeFolder;
            if (folder != null && folder.Name == "KuKu")
            {
            }

            PivotGridField pivotField = null;
            if (node.Field != null)
            {
                pivotField = ((PivotFieldItem)node.Field).Wrapper;
                // pivotField.TreeViewHeaderImage = 
            }

            var treeNode = (PivotCustomizationTreeNodeBase)node;
            Debug.WriteLine($"\t\t {treeNode.Name} ({GetFullPath(treeNode)} '{treeNode.Caption}'): flag {flag}");

            TreeViewItem treeViewItem1;
            if (flag)
            {
                treeViewItem1 = new TreeViewItem();
            }
            else
            {
                TreeViewItem treeViewItem2 = new TreeViewItem();
                treeViewItem2.Template = ListTreeViewItemTemplate;
                treeViewItem2.Background = ListTreeViewItenBackground;
                treeViewItem1 = treeViewItem2;
            }

            treeViewItem1.Tag = (object)flag;
            TreeViewFieldHeader treeViewFieldHeader;
            if (folder != null && folder.Name == "KuKu")
            {
                TreeViewFieldHeaderEx treeViewFieldHeaderEx = new TreeViewFieldHeaderEx(node);
                SetCanDragDropFolder(treeViewFieldHeaderEx, true);
                dynamic pivotGridField = new PrivateMembersInvoker(((PivotFieldItem)folder.FirstChild.Field).Wrapper);
                treeViewFieldHeaderEx.Owner = pivotGridField.PivotGrid;

                // treeViewFieldHeader.Field = ((PivotFieldItem)folder.FirstChild.Field).Wrapper;
                // FieldHeadersBase.SetFieldListArea(treeViewFieldHeader, FieldListArea.ColumnArea);


                treeViewFieldHeader = treeViewFieldHeaderEx;
            }
            else
            {
                treeViewFieldHeader = new TreeViewFieldHeaderCustomImage(node);
            }

            treeViewFieldHeader.ShowCheckBox = (node.Field != null && this.ShowCheckBoxes);
            // / images / export / exporttoxlsx_16x16.png
            //                       LargeGlyph="pack://application:,,,/DevExpress.Images.v14.1;component/Images/Export/ExportToXLS_32x32.png" />
            // 
            var imageSource1 = new BitmapImage(new Uri("pack://application:,,,/DevExpress.Images.v16.2;component/images/number%20formats/percentage_16x16.png"));

            treeViewFieldHeader.ImageSource = imageSource1;

            treeViewItem1.Header = treeViewFieldHeader;
            RoutedEventHandler routedEventHandler = (RoutedEventHandler)((s, e) =>
            {
                TreeViewItem treeViewItem2 = (TreeViewItem)s;
                ((TreeViewFieldHeader)treeViewItem2.Header).Node.IsExpanded = treeViewItem2.IsExpanded;
                e.Handled = true;
            });
            treeViewItem1.Expanded += routedEventHandler;
            treeViewItem1.Collapsed += routedEventHandler;
            return treeViewItem1;
        }

        private string GetFullPath(PivotCustomizationTreeNodeBase treeNode)
        {
            if (treeNode == null)
                return "<null>";

            if (treeNode.Parent == null)
            {
                if (treeNode is PivotCustomizationTreeNodeRoot)
                    return "root";

                return treeNode.GetType().Name;
            }

            return GetFullPath(treeNode.Parent) + @"\" + (String.IsNullOrEmpty(treeNode.Name) ? treeNode.GetType().Name : treeNode.Name);
        }

        private SolidColorBrush listTreeViewItenBackground;
        private SolidColorBrush ListTreeViewItenBackground
        {
            get
            {
                if (this.listTreeViewItenBackground == null)
                    this.listTreeViewItenBackground = new SolidColorBrush(Colors.Transparent);
                return this.listTreeViewItenBackground;
            }
        }

        private ControlTemplate listTreeViewItemTemplate;
        private ControlTemplate ListTreeViewItemTemplate
        {
            get
            {
                if (this.listTreeViewItemTemplate == null)
                    this.listTreeViewItemTemplate = XamlHelper.LoadObjectCore(
                            @"<ControlTemplate
                                xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""
                                xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""
                                TargetType=""{x:Type TreeViewItem}"">
                                    <ContentPresenter Content=""{TemplateBinding Header}"" HorizontalAlignment=""Stretch"" Margin=""10,2,4,2"" />
                            </ControlTemplate>") as ControlTemplate;
                return this.listTreeViewItemTemplate;
            }
        }

        #region Drag Drop

        /*        private Point startPoint;

                private void List_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
                {
                    // Store the mouse position
                    Point startPoint = e.GetPosition(null);
                }


                private void List_MouseMove(object sender, MouseEventArgs e)
                {
                    // Get the current mouse position
                    Point mousePos = e.GetPosition(null);
                    Vector diff = startPoint - mousePos;

                    if (e.LeftButton == MouseButtonState.Pressed &&
                        Math.Abs(diff.X) > SystemParameters.MinimumHorizontalDragDistance ||
                        Math.Abs(diff.Y) > SystemParameters.MinimumVerticalDragDistance)
                    {
                        // Get the dragged ListViewItem
                        ListView listView = sender as ListView;
                        ListViewItem listViewItem =
                            LayoutHelper.FindParentObject<ListViewItem>((DependencyObject) e.OriginalSource);

                        // Find the data behind the ListViewItem
                        object contact = listView.ItemContainerGenerator.
                            ItemFromContainer(listViewItem);

                        // Initialize the drag & drop operation
                        DataObject dragData = new DataObject("myFormat", contact);
                        DragDrop.DoDragDrop(listViewItem, dragData, DragDropEffects.Move);
                    }
                }*/

        #endregion

    }

    public class TreeViewFieldHeaderCustomImage : TreeViewFieldHeader
    {
        public TreeViewFieldHeaderCustomImage(IVisualCustomizationTreeItem node) :
            base(node)
        { }

/*
        protected override ImageSource GetImageSource(IVisualCustomizationTreeItem node)
        {
            var imageSource1 = new BitmapImage(new Uri("pack://application:,,,/DevExpress.Images.v16.2;component/images/number%20formats/percentage_16x16.png"));
            return imageSource1;
            // return (ImageSource)DevExpress.Xpf.PivotGrid.Internal.ImageHelper.GetImage(node.ImageName, false);
        }
*/
    }

    public class TreeViewFieldHeaderEx : TreeViewFieldHeaderCustomImage, ISupportDragDrop
    {
        public TreeViewFieldHeaderEx(IVisualCustomizationTreeItem node) :
            base(node)
        {
            bool canDragCore = this.CanDragCore;
            if (!canDragCore)
            {

            }
        }


        public PivotGridField FirstField
        {
            get
            {
                return ((PivotFieldItem)((PivotCustomizationTreeNodeFolder)Node).FirstChild.Field).Wrapper;
            }
        }

        public PivotGridControl Owner { get; set; }

        // ISupportDragDrop.CanStartDrag
        protected override bool CanDrag
        {
            get
            {
                bool result;
                bool canDragCore = this.CanDragCore;
                if (!canDragCore)
                {

                }

                if (TreeViewFieldsPresenterEx.GetCanDragDropFolder(this))
                    return true;

                if (this.Field == null || !this.CanDragCore)
                    result = false;
                else if (FieldHeadersBase.GetFieldListArea((DependencyObject)this) == DevExpress.Xpf.PivotGrid.FieldListArea.All)
                    result = this.Field.CanDragInCustomizationForm;
                else
                    result = this.Field.CanDrag;
                return result;
            }
        }

        // IDragElement ISupportDragDrop.CreateDragElement(Point offset)
        protected override IDragElement CreateDragElementCore(Point offset)
        {
            return (IDragElement)new TreeViewFieldHeaderDragElementEx((FieldHeaderBase)this, offset);
        }

        // implement, Field is null
        /*        public PivotGridControl PivotGrid
                {
                    get
                    {
                        if (this.Field == null)
                            return (PivotGridControl)null;
                        return this.Field.PivotGrid;
                    }
                }*/

        #region Implementation of ISupportDragDrop

        /*
                bool ISupportDragDrop.CanStartDrag(object sender, MouseButtonEventArgs e)
                {
                    return ((ISupportDragDrop)((FieldHeaderBase)this)).CanStartDrag(sender, e);

                    // return this.CanDrag;
                }
        */

        /*
                IDragElement ISupportDragDrop.CreateDragElement(Point offset)
                {
                    throw new NotImplementedException();
                }
        */

        IEnumerable<UIElement> ISupportDragDrop.GetTopLevelDropContainers()
        {
            dynamic pivotGrid = new PrivateMembersInvoker(Owner);
            PivotDragDropManager dragDropManager = pivotGrid.DragDropManager;
            return dragDropManager.GetTopLevelDropContainers();
        }

        /*        IDropTarget ISupportDragDrop.CreateEmptyDropTarget()
                {
                    throw new NotImplementedException();
                }
        */
        IDropTarget ISupportDragDrop.CreateEmptyDropTarget()
        {
            return (IDropTarget)new RemoveColumnDropTarget();
        }


        /*        bool ISupportDragDrop.IsCompatibleDropTargetFactory(IDropTargetFactory factory, UIElement dropTargetElement)
                {
                    throw new NotImplementedException();
                }
        */

        bool ISupportDragDrop.IsCompatibleDropTargetFactory(IDropTargetFactory factory, UIElement dropTargetElement)
        {
            return factory is PivotGridDropTargetFactoryExtension;
        }

        FrameworkElement ISupportDragDrop.SourceElement
        {
            get
            {
                return (FrameworkElement)this;
            }
        }

        #endregion
    }

    public class TreeViewFieldHeaderDragElementEx : TreeViewFieldHeaderDragElement
    {
        private FrameworkElement _sourceElement;

        public TreeViewFieldHeaderDragElementEx(FieldHeaderBase header, Point offset) :
            base(header, offset)
        {
        }

        protected override void AddGridChild(object child)
        {
            if (!(FieldHeader is TreeViewFieldHeaderEx))
            {
                throw new InvalidOperationException();
            }

            var treeViewFieldHeader = (TreeViewFieldHeaderEx)FieldHeader;
            ILogicalOwner pivotGrid = treeViewFieldHeader.Owner;
            pivotGrid.AddChild(child);
            /*
                            if (!(child is DependencyObject))
                                return;
                            FieldHeadersBase.SetFieldListArea((DependencyObject)child, FieldHeadersBase.GetFieldListArea((DependencyObject)this.FieldHeader));
            */
        }

        protected override void RemoveGridChild(object child)
        {
            if (!(FieldHeader is TreeViewFieldHeaderEx))
            {
                throw new InvalidOperationException();
            }

            var treeViewFieldHeader = (TreeViewFieldHeaderEx)FieldHeader;
            ILogicalOwner pivotGrid = treeViewFieldHeader.Owner;
            pivotGrid.RemoveChild(child);
        }

        public override void Destroy()
        {
            // base.Destroy()
            container.Close();
            RemoveGridChild(DragPreviewElement);

            if (!(FieldHeader is TreeViewFieldHeaderEx))
            {
                throw new InvalidOperationException();
            }

            var treeViewFieldHeader = (TreeViewFieldHeaderEx)FieldHeader;
            dynamic pivotGrid = new PrivateMembersInvoker(treeViewFieldHeader.Owner);
            pivotGrid.UserAction = UserAction.None;
        }
    }
}
