﻿using System;
using System.Diagnostics;
using System.Dynamic;
using System.Globalization;
using System.Linq;
using System.Reflection;

namespace WpfPivot_GettingStarted
{
    public class PrivateMembersInvoker : DynamicObject
    {
        static BindingFlags _bindingFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        private readonly object _obj;
        private readonly Type _type;
        public PrivateMembersInvoker(object obj)
        {
            _obj = obj;
            _type = obj.GetType();
        }

        public object UnderlyingObject => _obj;

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            var propInfo = _type.GetProperty(binder.Name, _bindingFlags);
            if (propInfo != null)
            {
                var value = propInfo.GetValue(_obj);

                Debug.WriteLine($"{nameof(PrivateMembersInvoker)}::TryGetMember: value {value.GetType().Name}");

                result = new PrivateMembersInvoker(value);
                return true;
            }

            return base.TryGetMember(binder, out result);
        }

        public override bool TrySetMember(SetMemberBinder binder, object value)
        {
            var propInfo = _type.GetProperty(binder.Name, _bindingFlags);
            if (propInfo != null)
            {
                propInfo.SetValue(_obj, value);

                Debug.WriteLine($"{nameof(PrivateMembersInvoker)}::TryGetMember: value {value.GetType().Name}");
                return true;
            }

            var fieldInfo = TryFindField(binder.Name);
            if (fieldInfo != null)
            {
                fieldInfo.SetValue(_obj, value);

                // Debug.WriteLine($"{nameof(PrivateMembersInvoker)}::TrySetMember: value {value.GetType().Name}");

                return true;
            }

            return base.TrySetMember(binder, value);
        }


        public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
        {
            // MethodInfo methodInfo = _type.GetMethod(binder.Name, BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Fla);
            MethodInfo methodInfo = (MethodInfo)TryFindPrivateMember(binder.Name);
            if (methodInfo != null)
            {
                var value = methodInfo.Invoke(_obj, _bindingFlags, null, args, CultureInfo.CurrentCulture);

                // Debug.WriteLine($"{nameof(PrivateMembersInvoker)}::TryInvokeMember: value {value.GetType().Name}");

                if (value != null)
                    result = new PrivateMembersInvoker(value);
                else
                    result = null;
                return true;
            }

            return base.TryInvokeMember(binder, args, out result);
        }

        public override bool TryConvert(ConvertBinder binder, out object result)
        {
            if (binder.ReturnType.IsInstanceOfType(UnderlyingObject))
            {
                result = UnderlyingObject;
                return true;
            }

            return base.TryConvert(binder, out result);
        }

        public override bool TryInvoke(InvokeBinder binder, object[] args, out object result)
        {
            return base.TryInvoke(binder, args, out result);
        }

        private MemberInfo TryFindPrivateMember(string membeName)
        {
            var type = _type;
            while (type != typeof(object))
            {
                var memberInfos = type.GetMember(membeName, BindingFlags.Instance | BindingFlags.NonPublic);
                if (memberInfos.Length > 0)
                {
                    if (memberInfos.Length > 1)
                        throw new InvalidOperationException($"more than one member {membeName} found");
                    return memberInfos[0];
                }

                type = type.BaseType;
            }

            return null;
        }

        private FieldInfo TryFindField(string fieldName)
        {
            var type = _type;
            while (type != typeof(object))
            {
                FieldInfo fieldInfo = type.GetField(fieldName, _bindingFlags);
                if (fieldInfo != null)
                    return fieldInfo;

                type = type.BaseType;
            }

            return null;
        }
    }
}