﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.PivotGrid;
using DevExpress.Xpf.PivotGrid.Internal;
using DevExpress.XtraPivotGrid;
using DevExpress.XtraPivotGrid.Data;

namespace WpfPivot_GettingStarted.DragDrop
{
    class AlmxInnerFieldListDropTarget : InnerFieldListDropTarget, IDropTarget
    {
        public AlmxInnerFieldListDropTarget(InnerFieldListControl innerFieldList) : base(innerFieldList)
        {
        }

        void IDropTarget.OnDragOver(UIElement source, Point pt)
        {
            object dragAnchor = (object)null;
            if (this.CanDropCore(source, pt, out dragAnchor, true))
            {
                if (this.DragAdorner == null)
                    ((dynamic)new PrivateMembersInvoker(this)).CreateDragIndicatorAdorner(source);
                this.UpdateDragAdornerLocationCore(source, dragAnchor);
            }
            else
                this.DestroyDragAdorner();
        }

        void IDropTarget.OnDragLeave()
        {
            this.DestroyDragAdorner();
        }

        void IDropTarget.Drop(UIElement source, Point pt)
        {
            object dragAnchor = (object)null;
            if (!this.CanDropCore(source, pt, out dragAnchor, false))
                return;
            this.MoveColumnToCore(source, dragAnchor);

        }

        protected override bool CanDropCore(
            UIElement source,
            Point pt,
            out object dragAnchor,
            bool isDrag)
        {
            int indexFromDragSource = this.GetDropIndexFromDragSource(source, pt);
            int dragIndex = this.GetDragIndex(indexFromDragSource);
            dragAnchor = (object)(isDrag ? dragIndex : indexFromDragSource);
            if (this.CanDrop(source, indexFromDragSource))
                return (int)dragAnchor != -1;
            return false;
        }

        protected override bool CanDrop(UIElement source, int dropIndex)
        {
            FieldHeaderBase fieldHeaderBase = source as FieldHeaderBase;
            if (fieldHeaderBase != null && fieldHeaderBase.DragDropHelper != null)
            {
                FieldHeaderDragElement dragElement = fieldHeaderBase.DragDropHelper.DragElement as FieldHeaderDragElement;
                if (dragElement != null)
                    ((dynamic)new PrivateMembersInvoker(this)).dragPreviewElement = dragElement.DragPreviewElement;
            }
            if (dropIndex < 0 || this.PivotGrid.IsAsyncInProgress)
                return false;
            if (fieldHeaderBase == null)
                return true;
            /*
                        if (fieldHeaderBase.Field != null && fieldHeaderBase.Field.PivotGrid != this.PivotGrid)
                            return false;
            */
            // *****************  HERE ******************************
            //          call for first field
            if (fieldHeaderBase is TreeViewFieldHeaderEx)
            {
                var fieldAreaChanging = FieldAreaChanging(((TreeViewFieldHeaderEx)fieldHeaderBase).FirstField, dropIndex, source);
                if (fieldAreaChanging)
                {

                }
                return fieldAreaChanging;
            }
            else
                return this.FieldAreaChanging(fieldHeaderBase.Field, dropIndex, source);
        }

        protected override void MoveColumnTo(UIElement source, int dropIndex)
        {
            PivotGridField field = FieldHeaderBase.GetField((DependencyObject)source);
            dynamic fieldDynamic = new PrivateMembersInvoker(field);
            dynamic pivotGridDynamic = new PrivateMembersInvoker(this.PivotChild);
            PivotGridWpfData pivotGridData = pivotGridDynamic.Data;
            if (this.IsRealSource)
            {
                if (this.FieldListArea.IsPivotArea())
                    this.SetFieldAreaPositionAsync(field, this.GetCorrectedDropIndex(dropIndex, source));
                else
                    fieldDynamic.Hide();
            }
            else if (this.FieldListArea.IsPivotArea())
                pivotGridData.FieldListFields.MoveField((PivotFieldItemBase)fieldDynamic.FieldItem, this.FieldListArea.ToPivotArea(), this.GetCorrectedDropIndex(dropIndex, source));
            else
                pivotGridData.FieldListFields.HideField((PivotFieldItemBase)fieldDynamic.FieldItem);
        }

        private void SetFieldAreaPositionAsync(PivotGridField field, int correctedIndex)
        {
            dynamic fieldDynamic = new PrivateMembersInvoker(field);
            this.Data.SetFieldAreaPositionAsync((PivotGridFieldBase)fieldDynamic.InternalField, this.FieldListArea.ToPivotArea(), correctedIndex, false);
        }



    }
}
