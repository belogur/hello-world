﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Core.Native;
using DevExpress.Xpf.PivotGrid;
using DevExpress.Xpf.PivotGrid.Internal;

namespace WpfPivot_GettingStarted.DragDrop
{
    public class AlmxPivotGridDropTargetFactory : PivotGridDropTargetFactoryExtension, IDropTargetFactory
    {
        IDropTarget IDropTargetFactory.CreateDropTarget(
            UIElement dropTargetElement)
        {
            FrameworkElement treeRoot = dropTargetElement as FrameworkElement;
            if (treeRoot != null && treeRoot.Name == "DragBorder")
            {
                return this.CreateCellsDropTargetCore((CellsAreaPresenter)LayoutHelper.FindElement(treeRoot, (Predicate<FrameworkElement>)(d => d is CellsAreaPresenter)));
            }

            Panel panel = dropTargetElement as Panel;
            if (panel != null)
                return (IDropTarget)this.CreateDropTargetCore(panel);
            FieldListControlBase fieldListControlBase = dropTargetElement as FieldListControlBase;
            if (fieldListControlBase != null)
                return (IDropTarget)this.CreateFieldListDropTargetCore((Control)fieldListControlBase);
            InnerFieldListControl innerFieldList = dropTargetElement as InnerFieldListControl;
            if (innerFieldList != null)
                return (IDropTarget)this.CreateInnerFieldListDropTargetCore(innerFieldList);
            PivotGridControl pivotGridControl = dropTargetElement as PivotGridControl;
            if (pivotGridControl != null)
                return (IDropTarget)this.CreateFieldListDropTargetCore((Control)pivotGridControl);
            FieldHeaders headers = dropTargetElement as FieldHeaders;
            if (headers != null)
                return (IDropTarget)this.CreateHeadersDropTargetCore(headers);
            DataAreaPopupEdit edit = dropTargetElement as DataAreaPopupEdit;
            if (edit != null)
                return (IDropTarget)this.CreateDataAreaHeadersDropTargetCore(edit);
            throw new ArgumentException("Cannot create a drop target for " + dropTargetElement.GetType().Name);
        }

        protected override PivotGridDropTargetBase CreateFieldListDropTargetCore(
            Control fieldList)
        {

            Debug.WriteLine("\t AlmxPivotGridDropTargetFactory.CreateFieldListDropTargetCore");

            PivotFieldListControl fieldListControl = fieldList as PivotFieldListControl;
            InnerFieldListControl innerFieldList = (InnerFieldListControl)null;
            if (fieldListControl != null)
                innerFieldList = (InnerFieldListControl)LayoutHelper.FindElement((FrameworkElement)fieldListControl, (Predicate<FrameworkElement>)(d => d is InnerFieldListControl));
            if (innerFieldList != null)
                return this.CreateInnerFieldListDropTargetCore(innerFieldList);
            return (PivotGridDropTargetBase)new PivotEmptyDropTarget(fieldList);
        }

        protected virtual PivotGridDropTargetBase CreateInnerFieldListDropTargetCore(
            InnerFieldListControl innerFieldList)
        {
            return new AlmxInnerFieldListDropTarget(innerFieldList);
        }
    }
}