﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Ch04
{
    class Widget
    {
        public virtual void Use()
        {
        }
    }

    class Customer
    {
        public Order LastOrder { get; set; }
    }
    class Order { }

    class Employee
    {
        public void OnEvent(object sender, EventArgs e) { }

        ~Employee() { Thread.Sleep(10000); }
    }

    class Program
    {
        static EventHandler MyEvent;

        static void Main(string[] args)
        {
            Console.WriteLine(GCSettings.IsServerGC);
            Console.WriteLine(GCSettings.LatencyMode);
            GCSettings.LatencyMode = GCLatencyMode.Interactive;

            MyEvent += new Employee().OnEvent;
            Employee e = new Employee();
            Employee e2 = new Employee();
            Console.ReadLine();
            Console.WriteLine(e.GetType().ToString());
            GC.Collect();
            Console.ReadLine();

            Customer customer = new Customer();
            GC.Collect();
            GC.Collect();
            customer.LastOrder = new Order();
            Console.ReadLine();

            Widget a = new Widget();
            a.Use();
            a.Use();
            Widget b = new Widget();
            b.Use();
            b.Use();
            a.Use();
            Console.ReadLine();
        }
    }
}
